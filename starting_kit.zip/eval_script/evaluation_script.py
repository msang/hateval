import pandas as pd
import numpy as np
import sys
from sklearn.metrics import accuracy_score, f1_score, precision_recall_fscore_support, precision_score, recall_score


def isfloat(value):
  try:
    float(value)
    return True
  except ValueError:
    return False


def check_file(path):
    f = open(path, 'r',encoding='utf-8')
    first_line = f.readlines()[0].split("\t")
    f.close()
    task_b = len(first_line) > 3
    if (isfloat(first_line[0])):
        has_header = 0
    else:
        has_header = 1
    return has_header, task_b


def load_data(path_goldstandard, path_outputfile):

    levels = ["HS", "TargetRange", "Aggressiveness"]

    ground_truth = pd.read_csv(path_goldstandard, sep= "\t", names=["ID","Tweet-text"] + levels, skiprows=check_file(path_goldstandard)[0], converters={0: str, 1: str, 2: int, 3: int, 4: int}, header=None, encoding = "utf-8")

    if (check_file(path_outputfile)[1]):
        converters = {0: str, 1: int, 2: int, 3: int}
    else :
        converters = {0: str, 1: int}
        levels = ["HS"]

    predicted = pd.read_csv(path_outputfile, sep = "\t", names=["ID"] + levels, skiprows=check_file(path_outputfile)[0], converters= converters, header=None)
    data = pd.merge(ground_truth, predicted, on="ID")

    # Check predicted classes
    for c in levels:
        gt_class = list(ground_truth[c].value_counts().keys())
        if not (predicted[c].isin(gt_class).all()):
            raise Exception("Wrong value in " + c + " prediction column.")

    return data, levels

def computeMeasures(data,levels):

    # Compute F-Measure
    f1_levels = dict.fromkeys(levels)
    for l in levels:
        f1_levels[l] = f1_score(data[l+"_x"], data[l+"_y"] , average= "macro")
    macro_f1 = np.mean(list(f1_levels.values()))

    # Compute Exact Match Ratio
    check_emr = np.ones(len(data), dtype=bool)
    for l in levels:
        check_label = data[l+"_x"] == data[l+"_y"]
        check_emr = check_emr & check_label
    emr = sum(check_emr) / len(data)

    return f1_levels, macro_f1, emr


def writeResults(path_result, path_outputfile, f1_levels, macro_f1, emr):

  # Write on file
  if (check_file(path_outputfile)[1]):
    path_result.write("F-measure (Hate_Speech): "+str(f1_levels["HS"])+"\n")
    path_result.write("Macro_F-measure: "+str(macro_f1)+"\n")
    path_result.write("EMR: "+str(emr))    
  else:
    path_result.write("F-measure (Hate_Speech): "+str(f1_levels["HS"])+"\n")  


def main(path_goldstandard, path_outputfile):
  path_result = open("scores.txt",'w')
  data, levels = load_data(path_goldstandard, path_outputfile)
  f1_levels, macro_f1, emr = computeMeasures(data,levels)
  writeResults(path_result, path_outputfile, f1_levels, macro_f1, emr)
  path_result.close()

if __name__ == '__main__':

    args = sys.argv[1:]

    if len(args) >= 2:
        path_goldstandard = args[0]
        path_outputfile = args[1]
        main(path_goldstandard, path_outputfile)
    else:
        sys.exit('''
                    Requires:
                    path_goldstandard -> Path of the gold standard
                    path_outputfile -> Path of the system's outputfile
                ''')


