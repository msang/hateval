#!/usr/bin/env python
import pandas as pd
import sys
import os
from sklearn.metrics import precision_recall_fscore_support, accuracy_score

def isfloat(value):
  try:
    float(value)
    return True
  except ValueError:
    return False


def check_file(path, correct_number_of_columns):
    f = open(path, 'r',encoding='utf-8')
    first_line = f.readlines()[0].split("\t")
    f.close()
    if (len(first_line) != correct_number_of_columns):
        sys.exit('Column format problem.')
    if (isfloat(first_line[0])):
        has_header = 0
    else:
        has_header = 1
    return has_header


def evaluate(pred,gold):
    levels = ["HS"]

    ground_truth = pd.read_csv(gold, sep="\t", names=["ID", "Tweet-text", "HS", "TargetRange", "Aggressiveness"],
                               skiprows=check_file(gold, 5),
                               converters={0: str, 1: str, 2: int, 3: int, 4: int}, header=None, encoding="utf-8")

    predicted = pd.read_csv(pred, sep="\t", names=["ID"] + levels , skiprows=check_file(pred, 2),
                            converters={0: str, 1: int}, header=None)

    # Check length files
    if (len(ground_truth) != len(predicted)):
        sys.exit('Prediction and gold data have different number of lines.')

    # Check predicted classes
    for c in levels:
        gt_class = list(ground_truth[c].value_counts().keys())
        if not (predicted[c].isin(gt_class).all()):
            sys.exit("Wrong value in " + c + " prediction column.")

    data = pd.merge(ground_truth, predicted, on="ID")

    if (len(ground_truth) != len(data)):
        sys.exit('Invalid tweet IDs in prediction.')

    # Compute Performance Measures HS
    acc_hs = accuracy_score(data["HS_x"], data["HS_y"])
    p_hs, r_hs, f1_hs, support = precision_recall_fscore_support(data["HS_x"], data["HS_y"], average = "macro")

    return acc_hs, p_hs, r_hs, f1_hs


def main(argv):
    # https://github.com/Tivix/competition-examples/blob/master/compute_pi/program/evaluate.py
    # as per the metadata file, input and output directories are the arguments

    [input_dir, output_dir] = argv

    # unzipped submission data is always in the 'res' subdirectory
    # https://github.com/codalab/codalab-competitions/wiki/User_Building-a-Scoring-Program-for-a-Competition#directory-structure-for-submissions

    gold_standard = os.path.join(input_dir, 'ref', 'gold_standard.tsv')

    submission_path = os.path.join(input_dir, 'res', 'pred.tsv')
    if not os.path.exists(submission_path):
        sys.exit('Could not find submission file {0}'.format(submission_path))

    acc_hs, p_hs, r_hs, f1_hs = evaluate(submission_path, gold_standard)

    # the scores for the leaderboard must be in a file named "scores.txt"
    # https://github.com/codalab/codalab-competitions/wiki/User_Building-a-Scoring-Program-for-a-Competition#directory-structure-for-submissions

    output_file = open(os.path.join(output_dir, 'scores.txt'), "w")

    output_file.write("EN_taskA_fscore:{0}\n".format(f1_hs))
    output_file.write("EN_taskA_precision:{0}\n".format(p_hs))
    output_file.write("EN_taskA_recall:{0}\n".format(r_hs))
    output_file.write("EN_taskA_accuracy:{0}\n".format(acc_hs))

    output_file.close()


if __name__ == "__main__":
    main(sys.argv[1:])

